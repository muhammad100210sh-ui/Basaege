# ЕГЭ — Моя база (Android project)

Android Studio project, package `ru.egemoyabaza`.

## Build
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

## Important implementation notes
- This is an initial functional prototype, not a finished production release.
- Materials are stored as JSON in the app's private local storage.
- Photos selected through Android photo picker are copied into app-private storage.
- OCR uses the ML Kit Latin recognizer. It is not a reliable Russian/Cyrillic recognizer and formula recognition is limited; replace with a Cyrillic-capable offline OCR engine for the full specification.
- Backup currently exports a JSON file to the app-specific external files directory. Full import/restore and packaging photos into the backup still need implementation.
- Rich text formatting, Room migration, multi-image OCR batching, robust delete/edit UX and production testing remain to be completed.
