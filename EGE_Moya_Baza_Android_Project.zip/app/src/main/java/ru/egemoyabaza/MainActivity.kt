package ru.egemoyabaza

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

private val Bg = Color(0xFF10131B)
private val Panel = Color(0xFF1B2030)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9BA3B7)

data class Note(val id: Long, val subject: String, val task: String, val section: String,
                val title: String, val body: String, val photos: List<String> = emptyList())

class Store(context: Context) {
    private val file = File(context.filesDir, "ege_data.json")
    private val gson = Gson()
    fun load(): MutableList<Note> = try {
        val t = object : TypeToken<MutableList<Note>>() {}.type
        gson.fromJson<MutableList<Note>>(file.readText(), t) ?: mutableListOf()
    } catch (_: Exception) { mutableListOf() }
    fun save(notes: List<Note>) { file.writeText(gson.toJson(notes)) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent, onBackground = Color.White,
            onSurface = Color.White
        )) { EgeApp(this, store) } }
    }
}

@Composable
fun EgeApp(context: Context, store: Store) {
    val notes = remember { mutableStateListOf<Note>().apply { addAll(store.load()) } }
    var subject by remember { mutableStateOf<String?>(null) }
    var task by remember { mutableStateOf<String?>(null) }
    var section by remember { mutableStateOf("Теория") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var activeNote by remember { mutableStateOf<Note?>(null) }
    var photoUris by remember { mutableStateOf(listOf<String>()) }
    var showSettings by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        photoUris = uris.mapNotNull { uri ->
            try {
                val dest = File(context.filesDir, "photo_${System.currentTimeMillis()}_${photoUris.size}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use(input::copyTo) }
                dest.absolutePath
            } catch (_: Exception) { null }
        }
    }

    fun persist() = store.save(notes.toList())
    fun saveNote() {
        val old = activeNote
        val new = Note(old?.id ?: System.currentTimeMillis(), subject ?: "Математика (профиль)",
            task ?: "Задание № 1", section, title.ifBlank { "Без названия" }, body, photoUris)
        if (old != null) {
            val index = notes.indexOfFirst { it.id == old.id }
            if (index >= 0) notes[index] = new
        } else notes.add(new)
        persist(); editing = false; activeNote = null; title = ""; body = ""; photoUris = emptyList()
    }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ЕГЭ — Моя база", fontSize = 25.sp, color = Color.White)
                    Text("Твоя личная библиотека подготовки", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Настройки", tint = Color.White) }
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(),
                placeholder = { Text("Поиск по всей базе…") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(14.dp))
            if (query.isNotBlank()) {
                Text("Результаты поиска", color = Muted)
                LazyColumn { items(notes.filter { it.title.contains(query, true) || it.body.contains(query, true) }) { n ->
                    NoteCard(n) { subject = n.subject; task = n.task; section = n.section; activeNote = n
                        title = n.title; body = n.body; photoUris = n.photos; editing = true }
                } }
            } else if (editing) {
                Text(if (activeNote == null) "Новый материал" else "Изменить материал", fontSize = 21.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Заголовок") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(body, { body = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Текст материала") }, minLines = 8)
                Text("${photoUris.size} фото прикреплено", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { photoPicker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, null); Text(" Фото") }
                    Button(onClick = {
                        val first = photoUris.firstOrNull() ?: return@Button
                        try {
                            val image = InputImage.fromFilePath(context, Uri.fromFile(File(first)))
                            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                                .addOnSuccessListener { body = (body + "\n" + it.text).trim() }
                        } catch (_: Exception) {}
                    }) { Text("Распознать текст") }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { saveNote() }, Modifier.weight(1f)) { Text("Сохранить") }
                    OutlinedButton(onClick = { editing = false }) { Text("Отмена") }
                }
            } else if (subject == null) {
                Text("Предметы", color = Muted)
                listOf("Математика (профиль)", "Информатика", "Русский язык").forEachIndexed { i, s ->
                    SubjectCard(s, listOf("∑", "</>", "А")[i], notes.count { it.subject == s }) { subject = s }
                }
                Spacer(Modifier.height(12.dp))
                Text("Всего материалов: ${notes.size}", color = Muted)
                Button(onClick = { exportBackup(context, notes) }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Backup, null); Text("  Создать резервную копию")
                }
            } else if (task == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { subject = null }) { Icon(Icons.Default.ArrowBack, null) }
                    Text(subject!!, fontSize = 21.sp)
                }
                val tasks = notes.filter { it.subject == subject }.map { it.task }.distinct().sorted()
                LazyColumn {
                    items((1..27).map { "Задание № $it" } + tasks.filter { t -> t !in (1..27).map { "Задание № $it" } }) { t ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { task = t },
                            colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(t, Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
                            }
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { task = null }) { Icon(Icons.Default.ArrowBack, null) }
                    Text("${subject} · $task", fontSize = 17.sp)
                }
                TabRow(selectedTabIndex = listOf("Теория","Примеры","Фотографии").indexOf(section).coerceAtLeast(0)) {
                    listOf("Теория","Примеры","Фотографии").forEach { tab ->
                        Tab(selected = section == tab, onClick = { section = tab }, text = { Text(tab, fontSize = 12.sp) })
                    }
                }
                val filtered = notes.filter { it.subject == subject && it.task == task && it.section == section }
                LazyColumn(Modifier.weight(1f)) {
                    items(filtered) { n ->
                        NoteCard(n) {
                            activeNote = n; title = n.title; body = n.body; photoUris = n.photos; editing = true
                        }
                        TextButton(onClick = { notes.remove(n); persist() }) { Text("Удалить", color = Color(0xFFFF7777)) }
                    }
                }
                Button(onClick = { activeNote = null; title = ""; body = ""; photoUris = emptyList(); editing = true },
                    Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  Добавить материал") }
            }
        }
    }
    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false },
        title = { Text("Настройки и резервная копия") },
        text = { Text("Данные хранятся локально на устройстве. Для переноса используйте кнопку резервного копирования на главном экране.") },
        confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Закрыть") } })
}

@Composable fun SubjectCard(name: String, symbol: String, count: Int, click: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = click),
        colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(symbol, color = Accent, fontSize = 27.sp, modifier = Modifier.width(48.dp))
            Column(Modifier.weight(1f)) { Text(name, fontSize = 17.sp); Text("$count материалов", color = Muted, fontSize = 12.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}
@Composable fun NoteCard(n: Note, click: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(onClick = click),
        colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(n.title, fontSize = 16.sp)
            Text(n.subject + " · " + n.task + " · " + n.section, color = Muted, fontSize = 11.sp)
            if (n.body.isNotBlank()) Text(n.body.take(180), color = Color.LightGray, fontSize = 13.sp)
            if (n.photos.isNotEmpty()) Text("Фото: ${n.photos.size}", color = Accent, fontSize = 11.sp)
        }
    }
}
fun exportBackup(context: Context, notes: List<Note>) {
    try {
        val file = File(context.getExternalFilesDir(null), "EGE_Moya_Baza_backup.json")
        file.writeText(Gson().toJson(notes))
        android.widget.Toast.makeText(context, "Копия сохранена: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
    } catch (_: Exception) {
        android.widget.Toast.makeText(context, "Не удалось создать копию", android.widget.Toast.LENGTH_LONG).show()
    }
}
